﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThinkLib; 

namespace Part_B
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int length(string s)
        {
            int count = 0;
            foreach(char i in s)
            {
                if(i == ' ')
                {
                    continue;
                }
                count++;
            }
            return count;
        }

        bool contains(string s, string subs)
        {
            int i = 0;

            foreach (char c in s)
            {
                if (c == subs[i])
                {
                    i++;
                    if (i == length(subs))
                    {
                        return true;
                    }
                }
                else
                {
                    i = 0;
                }
            }
            return false;
        }

        int indexOf(string s, string subs)
        {
            int i = 0;
            int j = 0;

            foreach (char c in s)
            {
                if (c == subs[i])
                {
                    i++;
                    if (i == length(subs))
                    {
                        return j + 1;
                    }


                }
                else
                {
                    i = 0;
                }
                j++;
               
            }
            return i;
        }

        string insertSubString(string s, string x, int pos)
        {

            int i = 0;
            string ans = "";
            while (i < pos)
            {
                ans += s[i];
                i++;
                    
            }
            ans += x;
            i = pos;
            while((i>= pos) && (i < length(s)))
            {
                ans += s[i];
                i++;
            }
            return ans;
 

        }

        string replaceSubString(string s, string ne, string old)
        {
            int a = indexOf(s, ne);
            string ans = insertSubString(s, ne, a);
            return ans;
        }


        //List<string> split(string s, char c)
        //{
        //    List<string> ans;
        //    for(int a = 0; a<length(s); a++)
        //    {
        //        if(a==' ')
        //        {

        //        }
        //    }


        //}

        int stringCompare(string s1, string s2)
        {
            int i = 0;
            if (length(s1) == length(s2) && s1[0] == s2[0])
            {

                foreach (char c in s1)
                {
                    if (c == s2[i])
                    {
                        i++;
                        return 0;
                    }

                    else
                    {
                        break;
                    }
                }

            }
            else if(s1[0] > s2[0])
            {
                return -1;
            }
            else if(s2[0] > s1[0])
            {
                return 1;
            }
            else if(s1[0] == s2[0])
            {
                int q = 1;

                if(s1[q] > s2[q])
                {
                    return -1;
                }
                else if(s2[q]> s1[q])
                {
                    return 1;
                }
                else
                {
                    q++;
                }
            }
            return 0;

            }

        //string toLower(string s)
        //{
        //    string ans = "";
            
        //    for(int i = 0; i<length(s); i++)
        //    {
        //        if(i<= 'Z' && i>= 'A')
        //        {
        //            ans = (char)(s[i] - 'A');
        //        }
        //        else
        //        {
        //            ans += s[i];
        //        }
        //    }
        
        //    return ans;
        //}



        private void button_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(length("q"), 1);
            Tester.TestEq(length("fjahfun"), 7);
            Tester.TestEq(length("    "), 0);
            Tester.TestEq(length("12456"), 5);
            Tester.TestEq(length(" hello"), 5);


            outBox.Text = Convert.ToString(length(textBox.Text));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(contains("qiz","z"), true);
            Tester.TestEq(contains("qhgush","a"), false);
            Tester.TestEq(contains("guy", " "), false);
            Tester.TestEq(contains("97y68", "8"), true);
            Tester.TestEq(contains("97yy68", "yy"), true);
            Tester.TestEq(contains("hello", "elp"), false);

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(indexOf("string","s"), 1);
            Tester.TestEq(indexOf("fjahfun","a"), 3);
            Tester.TestEq(indexOf("comment","t"), 7);
            Tester.TestEq(indexOf("12456","6"), 5);
            Tester.TestEq(indexOf("hello", "el"), 3);
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(insertSubString("xxxx", "z", 3), "xxxzx" );
            Tester.TestEq(insertSubString("xxxx", "z", 2), "xxzxx");
            Tester.TestEq(insertSubString("xxxx", "z", 1), "xzxxx");
            Tester.TestEq(insertSubString("cke", "a", 1), "cake");
            Tester.TestEq(insertSubString("phone", "i", 0), "iphone");
            Tester.TestEq(insertSubString("phone", "smart", 0), "smartphone");

        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(stringCompare("hello", "hello"), 0);
            Tester.TestEq(stringCompare("hallo", "hello"), -1);
            Tester.TestEq(stringCompare("quake", "hello"), 1);
            Tester.TestEq(stringCompare("hello", "apple"), -1);
            Tester.TestEq(stringCompare("apple", "hello"), -1);
            //Tester.TestEq(stringCompare("hello", "hello"), 0);

        }

        private void button7_Click(object sender, RoutedEventArgs e)
        {
            //Tester.TestEq(toLower("apPlE"), "apple");
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(replaceSubString("xxyxx", "ooo", "y"), "xxoooxx");
        }
    }
}
